import React from "react";
import "./Sidebar.css";
import Sidebar from "./Sidebar";

const Home = () => {
    return (
        <>
            <div className="userpage d-flex">
                hi
            </div>
        </>
    );
};

export default Home;